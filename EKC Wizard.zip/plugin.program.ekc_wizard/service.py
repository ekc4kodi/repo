import xbmc, xbmcgui, xbmcaddon, re, urllib2, time

AddonTitle="[COLOR dodgerblue]EKC[/COLOR] [COLOR white]Wizard[/COLOR]"
addon_id="plugin.program.ekc_wizard"
ADDON=xbmcaddon.Addon(id=addon_id)
pointerurl="https://ekc4kodi.github.io/repo/Pointer/"
Update=ADDON.getSetting('Update')
buildname=ADDON.getSetting('Name')
buildversion=ADDON.getSetting('Version')

def Open_Url(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link
    
    
time.sleep(15)
if Update=="true":
    try:
        link = Open_Url(pointerurl).replace('\n','').replace('\r','')
        match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)".+?ersion="(.+?)"').findall(link)
        for name,url,iconimage,fanart,description,version in match:
            if name == buildname:
                if version > buildversion:
                    if xbmcgui.Dialog().yesno(AddonTitle, '[COLOR white]An update has been detected for [/COLOR][COLOR dodgerblue]'+name+'[/COLOR]','', '[COLOR white]Would you like to open [/COLOR]'+AddonTitle+'[COLOR white]?[/COLOR]','[COLOR orangered]Skip[/COLOR]', '[COLOR dodgerblue]Open Wizard[/COLOR]'):
                        xbmc.executebuiltin('RunAddon('+addon_id+')')
    except: pass
